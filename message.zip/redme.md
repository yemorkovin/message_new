Backend: Django (Channels для WebSocket-соединений)\
Fronend: JS (WebSocket API)

pip install django channels


Для поддержки Channels Layers нужен
redis 

pip install channels_redis

